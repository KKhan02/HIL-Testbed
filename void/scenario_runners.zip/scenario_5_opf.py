"""
scenario_5_opf.py
=================
Scenario 5 — OPF Benchmark.

Runs one AC optimal power flow (runopp) per timestep.  The OPF simultaneously
optimises P and Q setpoints for all controllable DERs subject to:
    - Bus voltage limits  : 0.95–1.05 pu
    - Line thermal limits : 100 % rated current
    - Trafo thermal limits: 100 % rated current
    - DER P bounds        : [0, profile value]  (no curtailment beyond what's available)
    - DER Q bounds        : [−Q_max, +Q_max]   (VDE-AR-N 4110 Q_RATIO = 0.48)

Cost function — curtailment-minimising benchmark
-------------------------------------------------
All DERs are assigned a poly_cost with cp1_eur_per_mw = -1.  This tells the
solver to MAXIMISE total DER active power generation (equivalently, minimise
curtailment).  The OPF therefore represents the best achievable operating
point that satisfies all planning constraints while wasting the least DER
energy — a physically meaningful benchmark for comparing against Scenario 4.

This framing is intentional:
    cp1_eur_per_mw = -1   →   objective = -Σ p_mw   →   maximise generation
    net.sgen.max_p_mw     →   upper bound = available profile value at t

Any reduction in p_mw below max_p_mw in the OPF solution is curtailment.
The difference is logged per-timestep in TimestepRecord.p_applied_mw vs the
profile upper bound, and aggregated in ScenarioResult.curtailed_energy_mwh.

OPF setup discipline
--------------------
1. poly_cost rows are CLEARED before setup.  If this runner is called on a
   net that was previously used for another scenario or OPF configuration,
   stale poly_cost rows will conflict with the new cost entries.

2. OPF columns on net.sgen (controllable, min_p_mw, max_p_mw, min_q_mvar,
   max_q_mvar) are written once before the loop.  max_p_mw is updated each
   timestep to the profile value before runopp().

3. runopp() raises pandapower.optimal_powerflow.OPFNotConverged on failure.
   The runner catches this, logs a warning, and appends a non-converged
   TimestepRecord.  The run continues with the next timestep.

4. voltage_depend_loads=False must be passed via init_options, not as a
   direct kwarg to runopp().  runopp() does not accept arbitrary runpp kwargs.

Usage
-----
    from profile_builder import build_profiles
    from scenario_result import adapt_profiles
    from scenario_5_opf import run_scenario_5

    net      = sb.get_simbench_net("1-MV-rural--2-sw")
    profiles = build_profiles(net, ...)
    result   = run_scenario_5(net, profiles)

    print(result.curtailed_energy_mwh)
    print(result.n_violation_steps)   # should be 0 if OPF always feasible
"""

from __future__ import annotations

import logging
import time
from typing import Optional

import numpy as np
import pandapower as pp
import pandapower.optimal_powerflow
import pandas as pd

from volt_var_controller import Q_RATIO
from scenario_result import (
    AdaptedProfiles,
    ScenarioResult,
    TimestepRecord,
    adapt_profiles,
)

logger = logging.getLogger(__name__)

_V_MIN = 0.95
_V_MAX = 1.05


def _setup_opf(net, ap: AdaptedProfiles) -> None:
    """
    Prepare the network for OPF: set controllability, bounds, and costs.

    Called once before the timestep loop.  max_p_mw is set to a placeholder
    (the current net.sgen.p_mw) and updated per-timestep inside the loop.

    Cost rows are always cleared first to avoid duplicate or conflicting
    poly_cost entries from previous runs on the same net object.
    """
    # ------------------------------------------------------------------
    # [1] Clear existing poly_cost rows unconditionally.
    # ------------------------------------------------------------------
    if not net.poly_cost.empty:
        net.poly_cost.drop(net.poly_cost.index, inplace=True)
        logger.debug("_setup_opf: cleared %d existing poly_cost rows.", len(net.poly_cost))

    # ------------------------------------------------------------------
    # [2] Mark all DERs in ap.der_p as controllable.
    #     DERs not in der_p (absent from profiles) are left uncontrolled.
    # ------------------------------------------------------------------
    der_idx = ap.der_p.columns.tolist()

    net.sgen.loc[der_idx, "controllable"] = True

    # Active power bounds:
    #   min_p_mw = 0 (DERs cannot consume active power)
    #   max_p_mw = placeholder — updated per-timestep before runopp()
    net.sgen.loc[der_idx, "min_p_mw"] = 0.0
    net.sgen.loc[der_idx, "max_p_mw"] = net.sgen.loc[der_idx, "p_mw"].clip(lower=0.0)

    # Reactive power bounds: ±Q_RATIO × p_installed (sn_mva or p_mw fallback).
    # This mirrors the VDE-AR-N 4110 Bild 8 saturation limits exactly.
    sn   = net.sgen.loc[der_idx, "sn_mva"].values.astype(float)
    p_mw = net.sgen.loc[der_idx, "p_mw"].values.astype(float)
    use_sn  = np.isfinite(sn) & (sn > 0.0)
    p_rated = np.where(use_sn, sn, p_mw)

    q_max = Q_RATIO * np.abs(p_rated)
    net.sgen.loc[der_idx, "min_q_mvar"] = -q_max
    net.sgen.loc[der_idx, "max_q_mvar"] =  q_max

    # ------------------------------------------------------------------
    # [3] Bus voltage limits.
    # ------------------------------------------------------------------
    net.bus["min_vm_pu"] = _V_MIN
    net.bus["max_vm_pu"] = _V_MAX

    # ------------------------------------------------------------------
    # [4] Line and trafo thermal limits.
    # ------------------------------------------------------------------
    net.line["max_loading_percent"]  = 100.0
    net.trafo["max_loading_percent"] = 100.0

    # ------------------------------------------------------------------
    # [5] Curtailment-minimising cost: cp1_eur_per_mw = -1 for every DER.
    #     Objective = Σ cost_i × p_i = -Σ p_i  →  maximise generation.
    # ------------------------------------------------------------------
    for idx in der_idx:
        pp.create_poly_cost(net, idx, "sgen", cp1_eur_per_mw=-1.0)

    logger.info(
        "_setup_opf: %d DERs marked controllable, poly_cost created "
        "(cp1=-1, curtailment-minimising).",
        len(der_idx),
    )


def run_scenario_5(
        net,
        profiles:   dict,
        network_id: str   = "unknown",
        v_min:      float = _V_MIN,
        v_max:      float = _V_MAX,
        verbose_opf: bool = False,
) -> ScenarioResult:
    """
    Run Scenario 5 — OPF Benchmark (curtailment-minimising AC OPF).

    Parameters
    ----------
    net         : pandapower network.  Modified in place every timestep.
                  Caller should deep-copy if the original net is needed later.
    profiles    : dict from profile_builder.build_profiles().
    network_id  : human-readable identifier stored in ScenarioResult.
    v_min       : lower voltage planning limit (pu).  Default 0.95.
    v_max       : upper voltage planning limit (pu).  Default 1.05.
    verbose_opf : if True, passes verbose=True to runopp() for solver output.
                  Useful for debugging convergence failures.

    Returns
    -------
    ScenarioResult  with scenario_id="opf".

    Notes
    -----
    runopp() init_options
        voltage_depend_loads=False is passed via init_options["pf_options"].
        This is the only supported way to pass runpp-level flags to runopp().

    Convergence failures
        If runopp() raises OPFNotConverged, the timestep is logged as
        non-converged and the loop continues.  A high non-convergence rate
        signals that the OPF problem is infeasible at that timestep (e.g.
        no feasible voltage profile exists given the DER profile bound).

    Curtailed energy
        Computed as Σ_t Σ_i max(0, max_p_mw[i,t] − res_p[i,t]) × dt_h.
        max_p_mw[i,t] = profile value for DER i at timestep t (upper bound).
        res_p[i,t]    = OPF solution p_mw for DER i at timestep t.
        Stored per-record in _p_target (same hidden attribute pattern as S4).
    """
    t_start = time.perf_counter()

    ap: AdaptedProfiles = adapt_profiles(net, profiles)
    time_steps = range(len(ap.times))
    der_idx    = ap.der_p.columns

    logger.info(
        "[Scenario 5 | %s] Starting OPF benchmark: %d timesteps, "
        "%d DERs (%d PV + %d wind), %d loads",
        network_id, len(time_steps),
        len(der_idx), len(ap.pv_idx), len(ap.wind_idx), len(ap.load_idx),
    )

    # ------------------------------------------------------------------
    # Reset any ConstControls from a prior run.
    # ------------------------------------------------------------------
    net.controller.drop(net.controller.index, inplace=True)
    pp.reset_results(net)

    # ------------------------------------------------------------------
    # OPF setup (once before loop).
    # ------------------------------------------------------------------
    _setup_opf(net, ap)

    # init_options carry voltage_depend_loads into the internal runpp call.
    init_options = {"pf_options": {"voltage_depend_loads": False}}

    records: list[TimestepRecord] = []

    for t in time_steps:
        timestamp = ap.times[t]

        # [A] Update max_p_mw per DER to the profile value at this timestep.
        #     The OPF may choose any p in [0, profile_value]; reduction below
        #     the profile is curtailment.
        if not ap.der_p.empty:
            profile_row = ap.der_p.iloc[t].reindex(der_idx).fillna(0.0).values
            net.sgen.loc[der_idx, "max_p_mw"] = np.maximum(profile_row, 0.0)
            # min_p_mw stays 0 — no forced dispatch for renewables.
        else:
            profile_row = np.zeros(0, dtype=float)

        # [B] Load profiles (index-explicit).
        if not ap.load_p.empty:
            net.load.loc[ap.load_idx, "p_mw"]   = ap.load_p.iloc[t].values
            net.load.loc[ap.load_idx, "q_mvar"] = ap.load_q.iloc[t].values

        # [C] Run AC OPF.
        try:
            pp.runopp(
                net,
                verbose      = verbose_opf,
                init_options = init_options,
            )
            converged = True
        except pandapower.optimal_powerflow.OPFNotConverged as exc:
            logger.warning(
                "[Scenario 5 | %s] T=%d (%s): OPF did not converge — %s",
                network_id, t, timestamp, exc,
            )
            converged = False

        # [D] Build record.
        if converged:
            vm = net.res_bus["vm_pu"].copy()
            ll = net.res_line["loading_percent"].copy()
            tl = net.res_trafo["loading_percent"].copy()

            ov_buses  = vm.index[vm > v_max].tolist()
            uv_buses  = vm.index[vm < v_min].tolist()
            ov_lines  = ll.index[ll > 100.0].tolist()
            ov_trafos = tl.index[tl > 100.0].tolist()

            # OPF result: actual P and Q chosen by solver.
            p_result = net.res_sgen["p_mw"].reindex(der_idx).copy()
            q_result = net.res_sgen["q_mvar"].reindex(der_idx).copy()
        else:
            vm = pd.Series(dtype=float)
            ll = pd.Series(dtype=float)
            tl = pd.Series(dtype=float)
            ov_buses = uv_buses = ov_lines = ov_trafos = []
            p_result = None
            q_result = None

        rec = TimestepRecord(
            t=t, timestamp=timestamp,
            vm_pu=vm, line_loading=ll, trafo_loading=tl,
            over_voltage_buses=ov_buses, under_voltage_buses=uv_buses,
            overloaded_lines=ov_lines, overloaded_trafos=ov_trafos,
            q_applied_mvar=q_result,
            p_applied_mw=p_result,
            curtailment_needed=False,   # OPF manages curtailment internally
            converged=converged,
        )

        # Store profile upper bound as _p_target so from_records() can
        # compute curtailed_energy_mwh (profile_value - p_opf_solution).
        if converged and not ap.der_p.empty:
            rec._p_target = pd.Series(profile_row, index=der_idx, dtype=float)

        records.append(rec)

        if t % 96 == 0:
            logger.info(
                "[Scenario 5 | %s] t=%d/%d (%.1f %%) | "
                "violations=%d | non-converged=%d",
                network_id, t, len(time_steps),
                100.0 * t / max(len(time_steps), 1),
                sum(1 for r in records if r.over_voltage_buses
                    or r.under_voltage_buses),
                sum(1 for r in records if not r.converged),
            )

    elapsed = time.perf_counter() - t_start

    result = ScenarioResult.from_records(
        scenario_id = "opf",
        network_id  = network_id,
        records     = records,
        elapsed_s   = elapsed,
        dt_s        = ap.dt_s,
    )

    logger.info(
        "[Scenario 5 | %s] Done. %.1f s | %d/%d converged | "
        "%d violation steps | curtailed=%.3f MWh",
        network_id, elapsed, result.n_converged, result.n_timesteps,
        result.n_violation_steps,
        result.curtailed_energy_mwh or 0.0,
    )
    return result

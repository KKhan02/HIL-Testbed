"""
hiltest/networks.py
====================
Canonical representative network list, shared by all test sections.

Previously each section (violation_detector, volt_var, coordinator) defined
its own local copy of the same 9-network tuple list, creating maintenance
risk.  All sections now import REPRESENTATIVE_NETWORKS from here.

Tuple schemas
-------------
REPRESENTATIVE_NETWORKS (used by: violation, volt_var, coordinator)
    (test_name, loader_fn, label)

REPRESENTATIVE_NETWORKS_PLOTTER (used by: plotter — has extra simbench_code field)
    (test_name, loader_fn, net_name, simbench_code)

Both lists represent the same nine physical networks; the extra field in
REPRESENTATIVE_NETWORKS_PLOTTER is needed by build_annual_profiles().
"""

import pandapower.networks as pn
import simbench as sb


# ---------------------------------------------------------------------------
# Primary representative list — (test_name, loader_fn, label)
# Used by: violation.py, volt_var.py, coordinator.py
# ---------------------------------------------------------------------------
REPRESENTATIVE_NETWORKS = [
    ("sb_mv_rural",
     lambda: sb.get_simbench_net("1-MV-rural--2-sw"),
     "1-MV-rural--2-sw"),

    ("sb_lv_rural",
     lambda: sb.get_simbench_net("1-LV-rural1--0-sw"),
     "1-LV-rural1--0-sw"),

    ("sb_mvlv_rural",
     lambda: sb.get_simbench_net("1-MVLV-rural-all-0-sw"),
     "1-MVLV-rural-all-0-sw"),

    ("cigre_mv",
     lambda: pn.create_cigre_network_mv(with_der="pv_wind"),
     "cigre_mv"),

    ("cigre_lv",
     lambda: pn.create_cigre_network_lv(),
     "cigre_lv"),

    ("kerber_std",
     lambda: pn.create_kerber_landnetz_kabel_1(),
     "kerber_landnetz_kabel_1"),

    ("kerber_extreme",
     lambda: pn.kb_extrem_landnetz_kabel(),
     "kb_extrem_landnetz_kabel"),

    ("synthetic_lv",
     lambda: pn.create_synthetic_voltage_control_lv_network("rural_1"),
     "synthetic_lv_rural_1"),

    ("dickert",
     lambda: pn.create_dickert_lv_network("short", "cable", "single", "good"),
     "dickert"),
]


# ---------------------------------------------------------------------------
# Plotter representative list — (test_name, loader_fn, net_name, simbench_code)
# Used by: plotter.py (build_annual_profiles needs simbench_code kwarg)
# ---------------------------------------------------------------------------
REPRESENTATIVE_NETWORKS_PLOTTER = [
    ("sb_mv_rural",
     lambda: sb.get_simbench_net("1-MV-rural--2-sw"),
     "1-MV-rural--2-sw",      "1-MV-rural--2-sw"),

    ("sb_lv_rural",
     lambda: sb.get_simbench_net("1-LV-rural1--0-sw"),
     "1-LV-rural1--0-sw",     "1-LV-rural1--0-sw"),

    ("sb_mvlv_rural",
     lambda: sb.get_simbench_net("1-MVLV-rural-all-0-sw"),
     "1-MVLV-rural-all-0-sw", "1-MVLV-rural-all-0-sw"),

    ("cigre_mv",
     lambda: pn.create_cigre_network_mv(with_der="pv_wind"),
     "cigre_mv_with_der",     None),

    ("cigre_lv",
     lambda: pn.create_cigre_network_lv(),
     "cigre_lv",              None),

    ("kerber_standard",
     lambda: pn.create_kerber_landnetz_kabel_1(),
     "kerber_landnetz_kabel_1", None),

    ("kerber_extreme",
     lambda: pn.kb_extrem_landnetz_kabel(),
     "kb_extrem_landnetz_kabel", None),

    ("synthetic_lv",
     lambda: pn.create_synthetic_voltage_control_lv_network("rural_1"),
     "synthetic_lv_rural_1",  None),

    ("dickert",
     lambda: pn.create_dickert_lv_network("short", "cable", "single", "good"),
     "dickert_short_cable_single_good", None),
]

'''
Command-line entry point for the HIL CLI.

Flow:
1. Collect a RunPlan through the wizard
2. Print a human-readable summary.
3. Ask whether to proceed.
4. Optionally save the RunPlan as a preset JSON file.
5. Execute the run through the executor layer.
'''

from __future__ import annotations
import json
import sys
from pathlib import Path

from rich.prompt import Confirm, Prompt

from .wizard import run_wizard
from .helpers import print_run_plan, print_error_message
from ._console import console
#from . import executor

PRESET_DIR = Path("presets")

def _save_preset(plan) -> None:
    '''
    Save the selected RunPlan as a JSON preset
    '''

    preset_name = Prompt.ask("Preset name", console=console).strip()

    if not preset_name:
        console.print("[yellow]Preset not saved. Empty name provided.[/yellow]")
        return
    
    PRESET_DIR.mkdir(parents=True, exist_ok=True)
    
    preset_path = PRESET_DIR / f"{preset_name}.json"
    preset_json = json.dumps(plan.to_dict(), indent=2, sort_keys=True)

    preset_path.write_text(preset_json, encoding="utf-8")

    console.print(f"[green]Preset saved:[/green] {preset_path}")

def main() -> None:
    '''
    Run the HIL CLI workflow
    '''
    plan = run_wizard()

    print_run_plan(plan)

    proceed = Confirm.ask("Proceed?", default=True, console=console)

    if not proceed:
        console.print("[yellow]Cancelled.[/yellow]")
        sys.exit(0)
    
    save_as_preset = Confirm.ask("Save as preset?", default=False, console=console)

    if save_as_preset:
        _save_preset(plan)
    
    try:
#        executor.execute(plan)
        pass
    except Exception as exc:
        print_error_message(exc, context="Run execution failed")
        sys.exit(1)


if __name__ == "__main__":
    main()
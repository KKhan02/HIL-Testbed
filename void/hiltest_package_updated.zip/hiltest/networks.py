"""
hiltest/networks.py
====================
Network catalogue data — pure Python, no heavy imports.

Stores the representative network descriptors as plain tuples.
Loader lambdas are NOT here; they require pandapower/simbench and would
defeat the lazy-import goal.  Each section builds loaders inline using the
constants defined here.

Tuple schemas
-------------
REPRESENTATIVE_NETWORK_SPECS
    (test_name, sb_code_or_None, loader_tag, label)

    test_name   : unique key for --only filtering and TestCase naming
    sb_code     : SimBench code string, or None for non-SimBench networks
    loader_tag  : short string identifying which pandapower factory to call
                  (used by _make_loader() helpers in each section)
    label       : human-readable label for summaries and profile builder

REPRESENTATIVE_NETWORK_PLOTTER_SPECS
    Same as above with an additional simbench_code field needed by
    build_annual_profiles().
"""

# ---------------------------------------------------------------------------
# Representative networks — 9 entries, one per family
# (test_name, sb_code, loader_tag, label)
# ---------------------------------------------------------------------------
REPRESENTATIVE_NETWORK_SPECS = [
    ("sb_mv_rural",    "1-MV-rural--2-sw",      "simbench", "1-MV-rural--2-sw"),
    ("sb_lv_rural",    "1-LV-rural1--0-sw",     "simbench", "1-LV-rural1--0-sw"),
    ("sb_mvlv_rural",  "1-MVLV-rural-all-0-sw", "simbench", "1-MVLV-rural-all-0-sw"),
    ("cigre_mv",       None, "cigre_mv",         "cigre_mv"),
    ("cigre_lv",       None, "cigre_lv",         "cigre_lv"),
    ("kerber_std",     None, "kerber_landnetz_kabel_1",     "kerber_landnetz_kabel_1"),
    ("kerber_extreme", None, "kb_extrem_landnetz_kabel",    "kb_extrem_landnetz_kabel"),
    ("synthetic_lv",   None, "synthetic_lv_rural_1",        "synthetic_lv_rural_1"),
    ("dickert",        None, "dickert_short_cable_single_good", "dickert"),
]

# ---------------------------------------------------------------------------
# Plotter representative networks — extra simbench_code field
# (test_name, sb_code, loader_tag, net_name, simbench_code_for_profiles)
# ---------------------------------------------------------------------------
REPRESENTATIVE_NETWORK_PLOTTER_SPECS = [
    ("sb_mv_rural",    "1-MV-rural--2-sw",      "simbench",
     "1-MV-rural--2-sw",       "1-MV-rural--2-sw"),
    ("sb_lv_rural",    "1-LV-rural1--0-sw",     "simbench",
     "1-LV-rural1--0-sw",      "1-LV-rural1--0-sw"),
    ("sb_mvlv_rural",  "1-MVLV-rural-all-0-sw", "simbench",
     "1-MVLV-rural-all-0-sw",  "1-MVLV-rural-all-0-sw"),
    ("cigre_mv",       None, "cigre_mv",         "cigre_mv_with_der",     None),
    ("cigre_lv",       None, "cigre_lv",         "cigre_lv",              None),
    ("kerber_standard",None, "kerber_landnetz_kabel_1",
     "kerber_landnetz_kabel_1", None),
    ("kerber_extreme", None, "kb_extrem_landnetz_kabel",
     "kb_extrem_landnetz_kabel", None),
    ("synthetic_lv",   None, "synthetic_lv_rural_1",
     "synthetic_lv_rural_1",   None),
    ("dickert",        None, "dickert_short_cable_single_good",
     "dickert_short_cable_single_good", None),
]


def make_loader(loader_tag: str, sb_code: str | None):
    """
    Return a zero-argument callable that loads the network.

    Called inside section files after pandapower/simbench are already
    imported by that section — never at catalogue-read time.

    loader_tag conventions
    ----------------------
    "simbench"                          → sb.get_simbench_net(sb_code)
    "cigre_mv"                          → pn.create_cigre_network_mv(with_der="pv_wind")
    "cigre_lv"                          → pn.create_cigre_network_lv()
    "kerber_*" / "kb_extrem_*"          → getattr(pn, loader_tag)()
    "synthetic_lv_<class>"              → pn.create_synthetic_voltage_control_lv_network(<class>)
    "dickert_<fr>_<lt>_<cu>_<ca>"      → pn.create_dickert_lv_network(fr, lt, cu, ca)
    """
    import pandapower.networks as pn

    if loader_tag == "simbench":
        import simbench as sb
        code = sb_code
        return lambda: sb.get_simbench_net(code)

    if loader_tag == "cigre_mv":
        return lambda: pn.create_cigre_network_mv(with_der="pv_wind")

    if loader_tag == "cigre_lv":
        return lambda: pn.create_cigre_network_lv()

    if loader_tag.startswith("synthetic_lv_"):
        network_class = loader_tag[len("synthetic_lv_"):]
        return lambda nc=network_class: \
            pn.create_synthetic_voltage_control_lv_network(nc)

    if loader_tag.startswith("dickert_"):
        # tag format: dickert_<feeders>_<linetype>_<customer>_<case>
        # Only the four representative ones appear here; full catalogue in constants.py
        parts = loader_tag.split("_")
        # parts[0]="dickert", then feeders, linetype, customer, case
        # but linetype can be "cohl" (C&OHL) — not used in repr list so simple split OK
        fr, lt, cu, ca = parts[1], parts[2], parts[3], parts[4]
        return lambda f=fr, l=lt, c=cu, s=ca: \
            pn.create_dickert_lv_network(f, l, c, s)

    # Kerber standard and extreme: function name IS the loader_tag
    fn = getattr(pn, loader_tag, None)
    if fn is not None:
        return fn
    raise ValueError(f"Unknown loader_tag: {loader_tag!r}")

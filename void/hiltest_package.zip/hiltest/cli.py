"""
hiltest/cli.py
===============
Argument parsing and section routing for the hiltest package.
"""

import argparse

from hiltest.sections import SECTIONS, HW_SECTIONS


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="HIL Testbed master test suite",
        prog="python -m hiltest",
    )
    parser.add_argument(
        "--section",
        choices=list(SECTIONS.keys()),
        default=None,
        help="Run a single section only (default: all sections)",
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Print full tracebacks for all failures",
    )
    parser.add_argument(
        "--arduino-port",
        default=None,
        help="Serial port for hardware tests e.g. /dev/ttyACM0. "
             "If omitted, hardware subsections are skipped automatically.",
    )
    parser.add_argument(
        "--only-hw",
        action="store_true",
        help="Run hardware (Arduino) subsection only, skipping dry-run. "
             "Requires --arduino-port and --section to name a hardware-capable section.",
    )
    parser.add_argument(
        "--only",
        nargs="+",
        default=None,
        help="Run only test cases whose names contain any of these substrings. "
             "e.g. --only cigre kerber dickert era5",
    )
    return parser


def build_to_run(args: argparse.Namespace) -> dict:
    """
    Return the ordered dict of {section_name: run_fn} to execute.

    --only-hw fix (blocker 2): honouring --section when --only-hw is set.
    Previously to_run was hardcoded to volt_var_control regardless of
    --section.  Now --only-hw means "hardware block only within the requested
    section"; it requires --section to be provided and name a HW_SECTION.
    """
    if args.only_hw:
        if not args.arduino_port:
            raise SystemExit("--only-hw requires --arduino-port")
        if not args.section:
            raise SystemExit(
                "--only-hw requires --section to name a hardware-capable section: "
                + ", ".join(sorted(HW_SECTIONS))
            )
        if args.section not in HW_SECTIONS:
            raise SystemExit(
                f"--only-hw: section '{args.section}' has no hardware subsection. "
                f"Hardware-capable sections: {', '.join(sorted(HW_SECTIONS))}"
            )
        return {args.section: SECTIONS[args.section]}

    if args.section:
        return {args.section: SECTIONS[args.section]}

    return dict(SECTIONS)


def build_kwargs(section_name: str, args: argparse.Namespace) -> dict:
    """Return the keyword arguments to pass to a section's run function."""
    kwargs: dict = {"verbose": args.verbose, "only": args.only}
    if section_name in HW_SECTIONS:
        kwargs["arduino_port"] = args.arduino_port
        kwargs["only_hw"]      = args.only_hw
    return kwargs

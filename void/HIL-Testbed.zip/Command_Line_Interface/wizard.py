from rich.prompt import IntPrompt, FloatPrompt, Prompt
from .run_plan import NetworkConfig, DatasetConfig, ParameterConfig, RunPlan
from .network_catalogue import get_preset_families, get_presets_for_family
import ast

from ._console import console

def _ask(
        prompt: str,
        choices: list[tuple[str,str]],
        default: int | None = None,
) -> str:
    '''
    Show a numbered menu and return the selected machine-readable value.

    Parameters
    ----------
    prompt:
        Question shown above the menu.

    choices:
        List of (display_label, return_value) tuples.

    default:
        Optional zero-based default index into choices.
        Example: default=0 means option 1 is the default.

    Returns
    -------
    str
        The machine-readable return value from the selected choice.
    '''

    if not choices:
        raise ValueError("_ask() requires at least one choice")
    
    if default is not None and not 0 <= default < len(choices):
        raise ValueError(
            f"default index {default} is out of range for {len(choices)} choices."
        )
    
    console.print()
    console.print(f"[stage]{prompt}[/stage]")

    for index, (label,_) in enumerate(choices, start=1):
        console.print(f"[muted]{index}.[/muted] {label}")
    
    display_default = default + 1 if default is not None else None

    while True:
        selected_number = IntPrompt.ask(
            "Enter choice number",
            default=display_default,
            show_default=display_default is not None,
            console=console,
        )
        
        if 1 <= selected_number <= len(choices):
            selected_index = selected_number - 1
            return choices[selected_index][1]
        console.print(
            f"[error] Invalid choice.[/error] "
            f"Please enter a number between 1 and {len(choices)}."
        )

def _label_for_value(choices: list[tuple[str,str]], value:str) -> str:
    '''Return the display label for a selected machine-readable value'''
    return next(label for label, return_value in choices if return_value == value) 

def _ask_study() -> str:
    '''
    Ask which study runner should be used for this CLI run.

    Returns the machine-readable study name stored in Runplan.study
    '''
    return _ask(
        "Select study type",
        [
            (
                "Scenario comparison — run the 5 benchmark scenarios sequentially and compare results",
                "scenario_comparison",
            ),
            (
                "Voltage variation — run timestep-by-timestep voltage control with remediation logic",
                "voltage_variation",
            ),
            (
                "Hosting capacity — sweep PV penetration and find the first violation point",
                "hosting_capacity",
            ),
            (
                "OPF benchmark — run AC optimal power flow as a theoretical performance bound",
                "opf_benchmark",
            ),
        ],
        default=0
    )

def _ask_network() -> NetworkConfig:
    '''
    Ask how the pandapower network should be selected.
    Returns a fully populated NetworkConfig.
    '''

    source_type = _ask(
        "Select Network Source",
        [
            (
                "Curated preset catalogue — choose from the SimBench (Main), CIGRE, Kerber, Dickert, or Synthetic LV networks",
                "preset",  
            ),
            (
                "Assemble any SimBench network by code — build a code such as 1-LV-rural--0-sw from menu choices",
                "simbench_code",
            ),
            (
                "Custom Python network file — load your own pandapower network from a Python file",
                "custom",
            ),
        ],
        default=0,
    )

    if source_type == "preset":

        families = get_preset_families()
        family_choices = [
            (family_name, family_name)
            for family_name in families
        ]

        selected_family = _ask(
            "Select preset network family",
            family_choices,
            default=0,
        )

        preset_entries = get_presets_for_family(selected_family)
        preset_choices = [
            (entry["label"], entry["preset_name"])
            for entry in preset_entries
        ]

        selected_preset_name = _ask(
            f"Select preset network from {selected_family}",
            preset_choices,
            default=0,
        )

        return NetworkConfig(
            source_type="preset",
            preset_name=selected_preset_name,
            preset_family=selected_family,
        )

    elif source_type == "simbench_code":
        voltage_level_choices = [
            ("MV, medium-voltage network", "MV"),
            ("LV, low-voltage network", "LV"),
            ("MVLV, medium and low-voltage mixed network", "MVLV"),
        ]

        mv_grid_type_choices = [
            ("Rural MV grid", "rural"),
            ("Semi-urban MV grid", "semiurb"),
            ("Urban MV grid", "urban"),
            ("Commercial MV grid", "comm"),
        ]

        lv_grid_type_choices = [
            ("Rural LV grid 1", "rural1"),
            ("Rural LV grid 2", "rural2"),
            ("Rural LV grid 3", "rural3"),
            ("Semi-urban LV grid 4", "semiurb4"),
            ("Semi-urban LV grid 5", "semiurb5"),
            ("Urban LV grid 6", "urban6"),
        ]

        mvlv_subnet_choices_by_grid_type = {
            "rural": [
                ("All connected rural LV grids", "all"),
                ("Rural LV subnet 1.108", "1.108"),
                ("Rural LV subnet 2.107", "2.107"),
                ("Rural LV subnet 4.101", "4.101"),
            ],
            "semiurb": [
                ("All connected semi-urban LV grids", "all"),
                ("Semi-urban LV subnet 3.202", "3.202"),
                ("Semi-urban LV subnet 4.201", "4.201"),
                ("Semi-urban LV subnet 5.220", "5.220"),
            ],
            "urban": [
                ("All connected urban LV grids", "all"),
                ("Urban LV subnet 5.303", "5.303"),
                ("Urban LV subnet 6.305", "6.305"),
                ("Urban LV subnet 6.309", "6.309"),
            ],
            "comm": [
                ("All connected commercial LV grids", "all"),
                ("Commercial LV subnet 3.403", "3.403"),
                ("Commercial LV subnet 4.416", "4.416"),
                ("Commercial LV subnet 5.401", "5.401"),
            ],
        }

        scenario_level_choices = [
            ("Baseline scenario without DER or load scaling, Scenario 0", "0"),
            ("Future scenario with moderate load and DER growth, Scenario 1", "1"),
            ("Future scenario with high DER and load growth, Scenario 2", "2"),
        ]

        switching_suffix_choices = [
            ("Switched network, includes switch representation", "sw"),
            ("Unswitched network, no switch representation", "no_sw"),
        ]

        voltage_level = _ask(
            "Select SimBench voltage level",
            voltage_level_choices,
            default=0,
        )

        if voltage_level == "LV":
            grid_type = _ask(
                "Select SimBench LV grid type",
                lv_grid_type_choices,
                default=0,
            )
            lv_subnet = None

        else:
            grid_type = _ask(
                "Select SimBench MV grid type",
                mv_grid_type_choices,
                default=0,
            )

            if voltage_level == "MVLV":
                mvlv_subnet_choices = mvlv_subnet_choices_by_grid_type[grid_type]
                lv_subnet = _ask(
                    "Select connected LV subnet for the MVLV network",
                    mvlv_subnet_choices,
                    default=0,
                )
            else:
                lv_subnet = None

        scenario_level = _ask(
            "Select SimBench scenario level",
            scenario_level_choices,
            default=2,
        )

        switching_suffix = _ask(
            "Select SimBench switch representation",
            switching_suffix_choices,
            default=0,
        )

        if voltage_level == "MVLV":
            simbench_code = (
                f"1-MVLV-{grid_type}-{lv_subnet}-{scenario_level}-{switching_suffix}"
            )
        else:
            simbench_code = (
                f"1-{voltage_level}-{grid_type}--{scenario_level}-{switching_suffix}"
            )

        simbench_selections = {
            "Voltage Level": _label_for_value(voltage_level_choices, voltage_level),
            "Grid Type": (
                _label_for_value(lv_grid_type_choices, grid_type)
                if voltage_level == "LV"
                else _label_for_value(mv_grid_type_choices, grid_type)
            ),
            "Scenario Level": _label_for_value(scenario_level_choices, scenario_level),
            "Switch Representation": _label_for_value(
                switching_suffix_choices,
                switching_suffix,
            ),
        }

        if voltage_level == "MVLV":
            simbench_selections["Connected LV Subnet"] = _label_for_value(
                mvlv_subnet_choices_by_grid_type[grid_type],
                lv_subnet,
            )

        return NetworkConfig(
            source_type="simbench_code",
            simbench_code=simbench_code,
            simbench_selections=simbench_selections,
        )
    elif source_type == "custom":

        custom_path = Prompt.ask(
            "Enter path to custom Python network file",
            console=console,
        )
        custom_function_name = Prompt.ask(
            "Enter network factory function name",
            default="get_network",
            console=console,
        )

        return NetworkConfig(
            source_type="custom",
            custom_path=custom_path,
            custom_function_name=custom_function_name,
        )
    
    else:
        raise RuntimeError(f"Unexpected network source type: {source_type}")


def _ask_optional_dict(prompt: str) -> dict | None:
    '''
    Ask for an optional dictionary override.
    
    Pressing Enter returns None. A non-empty answer must have a valid
    Python dict literal, for example: {"solar": "solar.csv", "wind": "wind.csv"}.
    '''

    while True:
        console.print()
        console.print(f"[stage]{prompt}[/stage]")
        console.print("[muted]Press Enter for no scaling, or enter a dict, e.g.[/muted]")
        console.print("[cyan]{None: 1.0}[/cyan] or [cyan]{12: 1.5, 15: 0.8}[/cyan]")

        raw_value = Prompt.ask(
            prompt,
            default="",
            show_default=False,
            console=console,
        ).strip()

        if not raw_value:
            return None
        
        try:
            parsed_value = ast.literal_eval(raw_value)
        except (SyntaxError, ValueError):
            console.print(
                "[error]Invalid dictionary format.[/error] "
                "Use a Python dict literal, for example: "
                '{"solar": "solar.csv", "wind": "wind.csv"}'
            )
            continue

        if not isinstance(parsed_value, dict):
            console.print("[error]Invalid input.[/error] Please enter a dictionary.")
            continue
        
        return parsed_value
    
def _ask_dataset() -> DatasetConfig:
    '''
    Ask which dataset source should be used for this run.

    Returns a fully populated DatasetConfig for the selected source type.
    '''

    source_type = _ask(
        "Select dataset source",
        [
            (
                "SimBench native profiles — use time-series profiles bundled with the selected SimBench network",
                "simbench_native",
            ),
            (
                "DWD Climate Data Centre files — build profiles from the standard project DWD folder structure",
                "dwd",
            ),
            (
                "Custom dataset file — use a user-provided profile file with optional file and column mappings",
                "custom",
            ),
        ],
        default=1
    )

    if source_type == "simbench_native":
        return DatasetConfig(
            source_type="simbench_native",
        )
    elif source_type == "dwd":
        data_dir = Prompt.ask(
            "Enter DWD data directory",
            default="data/dwd",
            console=console,
        )
        station_id = Prompt.ask(
            "Enter DWD Station ID",
            default="691",
            console=console
        )
        year = IntPrompt.ask(
            "Enter dataset year",
            default=2024,
            console=console,
        )
        return DatasetConfig(
            source_type="dwd",
            data_dir=data_dir,
            station_id=station_id,
            year=year,
        )
    elif source_type == "custom":
        custom_path = Prompt.ask(
            "Enter path to custom dataset file",
            console=console,
        )

        file_map = _ask_optional_dict(
            "Optional file_map override — maps profile type to filename.\n"
            "Press Enter to skip, or enter a dict, e.g.\n"
            '{"RAD-G": "solar_691.csv", "F": "wind_691.csv", "T2M": "temp_691.csv"}'
        )

        col_map = _ask_optional_dict(
            "Optional col_map override — maps profile type to column name within the file.\n"
            "Press Enter to skip, or enter a dict, e.g.\n"
            '{"timestamp": "Zeitstempel", "solar": "Wert", "wind": "Wert", "temp": "Wert", "sep": ","}'
        )

        return DatasetConfig(
            source_type="custom",
            custom_path=custom_path,
            file_map=file_map,
            col_map=col_map,
        )
    
    else:
        raise RuntimeError(f"Unexpected dataset source type: {source_type}")

def _ask_scaling_dict(prompt: str) -> dict:
    '''
    Ask for an optional scaling dictionary.

    Pressing Enter returns the default no-scaling convention: {None: 1.0}.    
    '''

    scaling = _ask_optional_dict(prompt)
    return scaling if scaling is not None else {None: 1.0}

def _ask_parameters() -> ParameterConfig:
    '''
    Ask for numerical simulation limits, scaling, and timestep resolution.

    Returns a fully populated ParameterConfig.
    '''

    v_min = FloatPrompt.ask(
        "Enter minimum voltage limit in pu",
        default=0.95,
        console=console
    )

    v_max = FloatPrompt.ask(
        "Enter maximum voltage limit in pu",
        default=1.05,
        console=console,
    )

    line_max_loading = IntPrompt.ask(
        "Enter maximum line loading in percent",
        default=100,
        console=console,
    )

    trafo_max_loading = IntPrompt.ask(
        "Enter maximum transformer loading in percent",
        default=100,
        console=console,
    )

    va_diff_max_degree = IntPrompt.ask(
        "Enter maximum voltage angle difference in degrees",
        default=30,
        console=console,
    )

    unbalance_max_percent = FloatPrompt.ask(
        "Enter maximum voltage unbalance in percent",
        default=2.0,
        console=console,
    )

    timestep_resolution = int(
        _ask(
            "Select timestep resolution",
            [
                ("15 minutes, SimBench native profile resolution", "15"),
                ("10 minutes, DWD weather data resolution", "10"),
            ],
            default=0,
        )
    )
    der_scaling = _ask_scaling_dict(
        "Optional DER scaling override — maps bus index to scaling factor."
    )
    load_scaling = _ask_scaling_dict(
        "Optional load scaling override — maps bus index to scaling factor."
    )

    return ParameterConfig(
        v_min=v_min,
        v_max=v_max,
        line_max_loading=line_max_loading,
        trafo_max_loading=trafo_max_loading,
        va_diff_max_degree=va_diff_max_degree,
        unbalance_max_percent=unbalance_max_percent,
        der_scaling=der_scaling,
        load_scaling=load_scaling,
        timestep_resolution=timestep_resolution,
    )

def _ask_execution_mode() -> str:
    return _ask(
        "Select execution mode",
        [
            (
                "Rerun, re-execute the full time horizon for side-by-side benchmarking",
                "rerun",
            ),
            (
                "Continue, apply corrections as needed and move forward for online/HIL runs",
                "continue",
            ),
        ],
        default=0,
    )


def _ask_remediation_profile() -> str:
    return _ask(
        "Select remediation profile",
        [
            (
                "Research, run all remediation steps regardless for comparison",
                "research",
            ),
            (
                "Conservative, apply minimum intervention only",
                "conservative",
            ),
            (
                "Aggressive, escalate fully without prompting",
                "aggressive",
            ),
            (
                "Interactive, ask before each escalation step",
                "interactive",
            ),
        ],
        default=0,
    )

def run_wizard() -> RunPlan:
    """
    Run the interactive CLI wizard and return a complete RunPlan.

    This is the only public function in wizard.py. __main__.py calls this
    function, then passes the returned RunPlan to the next CLI layer.
    """

    study = _ask_study()
    execution_mode = _ask_execution_mode()
    remediation_profile = _ask_remediation_profile()
    network = _ask_network()
    dataset = _ask_dataset()
    params = _ask_parameters()

    return RunPlan(
        study=study,
        execution_mode=execution_mode,
        remediation_profile=remediation_profile,
        network=network,
        dataset=dataset,
        parameters=params,
    )
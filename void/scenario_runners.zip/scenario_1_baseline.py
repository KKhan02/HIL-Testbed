"""
scenario_1_baseline.py
======================
Scenario 1 — Baseline (no control).

Runs a full annual time series using pandapower's built-in run_timeseries()
engine with ConstControl data sources.  No reactive power control, no Arduino,
no manual timestep loop.  This is the reference against which all controlled
scenarios are compared.

Violation detection runs in post-processing from the OutputWriter logs, not
inside the loop.  This is correct for Scenario 1 — the no-control reference
never needs per-timestep hooks.

Usage
-----
    from profile_builder import build_profiles
    from scenario_result import adapt_profiles
    from scenario_1_baseline import run_scenario_1

    net      = sb.get_simbench_net("1-MV-rural--2-sw")
    profiles = build_profiles(net, ...)
    result   = run_scenario_1(net, profiles)

    print(result.n_violation_steps)
    df = pd.DataFrame([result.summary_dict()])

Notes
-----
voltage_depend_loads=False is passed via run_timeseries's run_control_fct
kwargs mechanism.  This is mandatory for SimBench networks on pandapower
3.2.0+ (singular matrix without it).  It is enforced inside this runner
and must not be removed.

ConstControl columns must be integer sgen/load indices, not positional
integers.  This is enforced by the DataFrame column construction below.
"""

from __future__ import annotations

import logging
import time
from typing import Optional

import numpy as np
import pandapower as pp
import pandapower.control as ctrl
import pandapower.timeseries as ts
from pandapower.timeseries import DFData, OutputWriter
import pandas as pd

from scenario_result import (
    AdaptedProfiles,
    ScenarioResult,
    TimestepRecord,
    adapt_profiles,
    make_record_from_report,
)

logger = logging.getLogger(__name__)

# Voltage planning limits — mirrored from violation_detector.py constants.
# If the violation_detector thresholds are ever changed, update here too.
_V_MIN = 0.95
_V_MAX = 1.05


def run_scenario_1(
        net,
        profiles:   dict,
        network_id: str  = "unknown",
        v_min:      float = _V_MIN,
        v_max:      float = _V_MAX,
) -> ScenarioResult:
    """
    Run Scenario 1 — Baseline (no voltage control).

    Parameters
    ----------
    net        : pandapower network.  Modified in place by run_timeseries;
                 caller should deep-copy if the original net is needed later.
    profiles   : dict from profile_builder.build_profiles().
    network_id : human-readable identifier stored in ScenarioResult.
    v_min      : lower voltage planning limit (pu).  Default 0.95.
    v_max      : upper voltage planning limit (pu).  Default 1.05.

    Returns
    -------
    ScenarioResult  with scenario_id="baseline".
    """
    t_start = time.perf_counter()

    ap: AdaptedProfiles = adapt_profiles(net, profiles)
    time_steps = range(len(ap.times))

    logger.info(
        "[Scenario 1 | %s] Starting baseline run: %d timesteps, "
        "%d DERs (%d PV + %d wind), %d loads",
        network_id, len(time_steps),
        len(ap.der_p.columns), len(ap.pv_idx), len(ap.wind_idx),
        len(ap.load_idx),
    )

    # ------------------------------------------------------------------
    # [1] Reset any existing controllers and result tables
    # ------------------------------------------------------------------
    net.controller.drop(net.controller.index, inplace=True)
    pp.reset_results(net)

    # ------------------------------------------------------------------
    # [2] Attach ConstControl for DER active power
    #     One ConstControl per element type (sgen, load) is sufficient;
    #     pandapower maps columns to element indices via element_index.
    # ------------------------------------------------------------------
    if not ap.der_p.empty:
        der_ds = DFData(ap.der_p.copy())
        ctrl.ConstControl(
            net,
            element         = "sgen",
            element_index   = ap.der_p.columns.tolist(),
            variable        = "p_mw",
            data_source     = der_ds,
            profile_name    = ap.der_p.columns.tolist(),
        )

    if not ap.load_p.empty:
        load_p_ds = DFData(ap.load_p.copy())
        ctrl.ConstControl(
            net,
            element         = "load",
            element_index   = ap.load_p.columns.tolist(),
            variable        = "p_mw",
            data_source     = load_p_ds,
            profile_name    = ap.load_p.columns.tolist(),
        )

        load_q_ds = DFData(ap.load_q.copy())
        ctrl.ConstControl(
            net,
            element         = "load",
            element_index   = ap.load_q.columns.tolist(),
            variable        = "q_mvar",
            data_source     = load_q_ds,
            profile_name    = ap.load_q.columns.tolist(),
        )

    # ------------------------------------------------------------------
    # [3] OutputWriter — log vm_pu, line loading, trafo loading
    #     These are the only tables needed for post-processing.
    # ------------------------------------------------------------------
    ow = OutputWriter(net, time_steps, output_path=None, log_variables=list())
    ow.log_variable("res_bus",   "vm_pu")
    ow.log_variable("res_line",  "loading_percent")
    ow.log_variable("res_trafo", "loading_percent")

    # ------------------------------------------------------------------
    # [4] Run time series
    #     voltage_depend_loads=False is mandatory for SimBench networks.
    #     continue_on_divergence=True prevents a single non-converging
    #     timestep from aborting the full annual run.
    # ------------------------------------------------------------------
    logger.info("[Scenario 1 | %s] Calling run_timeseries ...", network_id)
    ts.run_timeseries(
        net,
        time_steps              = time_steps,
        continue_on_divergence  = True,
        verbose                 = False,
        run_control_fct_kwargs  = {"voltage_depend_loads": False},
    )
    logger.info("[Scenario 1 | %s] run_timeseries complete.", network_id)

    # ------------------------------------------------------------------
    # [5] Post-process OutputWriter results into TimestepRecord list
    #     ow.output["res_bus.vm_pu"] is a DataFrame (T × N_buses).
    #     ow.output["res_line.loading_percent"] is (T × N_lines).
    #     Row index = integer timestep (matching time_steps range).
    # ------------------------------------------------------------------
    vm_log   = ow.output.get("res_bus.vm_pu",         pd.DataFrame())
    ll_log   = ow.output.get("res_line.loading_percent",  pd.DataFrame())
    tl_log   = ow.output.get("res_trafo.loading_percent", pd.DataFrame())

    records = []
    for t in time_steps:
        timestamp = ap.times[t]

        # A timestep that did not converge is absent from the log or
        # filled with NaN; detect it by checking for NaN in vm_pu row.
        if vm_log.empty or t not in vm_log.index or vm_log.loc[t].isna().all():
            converged = False
        else:
            converged = True

        if not converged:
            records.append(TimestepRecord(
                t=t, timestamp=timestamp,
                vm_pu=pd.Series(dtype=float),
                line_loading=pd.Series(dtype=float),
                trafo_loading=pd.Series(dtype=float),
                over_voltage_buses=[], under_voltage_buses=[],
                overloaded_lines=[], overloaded_trafos=[],
                q_applied_mvar=None, p_applied_mw=None,
                curtailment_needed=False, converged=False,
            ))
            continue

        vm   = vm_log.loc[t].dropna()
        ll   = ll_log.loc[t].dropna() if not ll_log.empty else pd.Series(dtype=float)
        tl   = tl_log.loc[t].dropna() if not tl_log.empty else pd.Series(dtype=float)

        ov_buses  = vm.index[vm > v_max].tolist()
        uv_buses  = vm.index[vm < v_min].tolist()
        ov_lines  = ll.index[ll > 100.0].tolist()
        ov_trafos = tl.index[tl > 100.0].tolist()

        records.append(TimestepRecord(
            t=t, timestamp=timestamp,
            vm_pu=vm, line_loading=ll, trafo_loading=tl,
            over_voltage_buses=ov_buses, under_voltage_buses=uv_buses,
            overloaded_lines=ov_lines, overloaded_trafos=ov_trafos,
            q_applied_mvar=None,   # no reactive control in Scenario 1
            p_applied_mw=None,     # no ramp limiting in Scenario 1
            curtailment_needed=False,
            converged=True,
        ))

    elapsed = time.perf_counter() - t_start

    result = ScenarioResult.from_records(
        scenario_id = "baseline",
        network_id  = network_id,
        records     = records,
        elapsed_s   = elapsed,
        dt_s        = ap.dt_s,
    )

    logger.info(
        "[Scenario 1 | %s] Done. %.1f s | %d/%d converged | %d violation steps",
        network_id, elapsed, result.n_converged, result.n_timesteps,
        result.n_violation_steps,
    )
    return result

"""
hiltest/sections/__init__.py
=============================
Section registry — maps CLI section name to run function.
"""
from hiltest.sections.profile_builder import run_profile_builder_tests
from hiltest.sections.plotter         import run_network_plotter_tests
from hiltest.sections.violation       import (
    run_violation_detector_tests,
    run_violation_detector_all_tests,
)
from hiltest.sections.volt_var        import run_volt_var_tests
from hiltest.sections.coordinator     import (
    run_sensitivity_coordinator_tests,
    run_sensitivity_coordinator_all_tests,
)

SECTIONS = {
    "profile_builder":            run_profile_builder_tests,
    "network_plotter":            run_network_plotter_tests,
    "violation_detector":         run_violation_detector_tests,
    "violation_detector_all":     run_violation_detector_all_tests,
    "volt_var_control":           run_volt_var_tests,
    "sensitivity_coordinator":    run_sensitivity_coordinator_tests,
    "sensitivity_coordinator_all": run_sensitivity_coordinator_all_tests,
    # "baseline":          run_baseline_tests,
    # "oltc":              run_oltc_tests,
    # "svc":              run_svc_tests,
    # "hil":              run_hil_tests,
    # "opf":              run_opf_tests,
    # "hosting_capacity": run_hosting_capacity_tests,
}

# Sections that accept arduino_port and only_hw kwargs
HW_SECTIONS = {"volt_var_control", "sensitivity_coordinator",
               "sensitivity_coordinator_all"}

"""
hiltest/__main__.py
====================
Entry point: python -m hiltest [options]

CI exit-code fix: sys.exit(1) when any test case failed (non-zero exit
code allows CI pipelines to detect failures correctly).
"""

import sys
import time

from hiltest.cli      import build_parser, build_to_run, build_kwargs
from hiltest.framework import print_summary


def main() -> None:
    parser   = build_parser()
    args     = parser.parse_args()
    to_run   = build_to_run(args)
    t_start  = time.perf_counter()

    section_results: dict = {}

    for section_name, run_fn in to_run.items():
        print(f"\n{'='*70}")
        print(f"  SECTION: {section_name.upper()}")
        print(f"{'='*70}")

        kwargs = build_kwargs(section_name, args)
        cases  = run_fn(**kwargs)
        section_results[section_name] = cases

    any_failure = print_summary(section_results)
    print(f"\n  Total time: {time.perf_counter() - t_start:.1f}s")

    # CI fix: non-zero exit when any test failed
    if any_failure:
        sys.exit(1)


if __name__ == "__main__":
    main()

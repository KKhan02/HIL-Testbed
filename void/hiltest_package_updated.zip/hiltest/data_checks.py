"""
hiltest/data_checks.py
=======================
Shared profile sanity checks used by profile_builder and plotter sections.
"""

import numpy as np
import pandas as pd

from hiltest.framework import TestCase


def check_profiles(tc: TestCase, result: dict,
                   check_pv_night: bool = False) -> None:
    """
    Populate tc with standard profile_builder sanity checks.

    Parameters
    ----------
    tc              : TestCase to record checks into.
    result          : Dict returned by build_annual_profiles().
    check_pv_night  : If True, verify PV output is zero between 22:00–04:00.
    """
    required = {"load", "pv", "wind", "times", "net_type", "extreme_days"}
    missing  = required - set(result.keys())
    tc.record("required_keys", not missing,
              f"Missing: {missing}" if missing else "")

    times = result.get("times", pd.DatetimeIndex([]))
    tc.record("timestep_count", len(times) > 100,
              f"Only {len(times)} timesteps")

    extreme = result.get("extreme_days", {})
    tc.record("extreme_days_exists", isinstance(extreme, dict), "Not a dict")
    tc.record(
        "extreme_days_keys",
        all(k in extreme for k in ("max_der", "min_der", "max_load", "min_load")),
        f"Keys present: {list(extreme.keys())}",
    )

    # Load checks
    load_df = result.get("load")
    if isinstance(load_df, pd.DataFrame) and not load_df.empty:
        bad = load_df.columns[load_df.isna().all()].tolist()
        tc.record("load_no_all_nan",   not bad,   f"All-NaN cols: {bad}")
        tc.record("load_sum_positive", load_df.sum().sum() > 0,
                  "All load values are zero")
        tc.record("load_no_negative",  (load_df >= 0).all().all(),
                  "Negative load values found")
    else:
        tc.record("load_exists", False, "Load DataFrame missing or empty")

    # PV checks
    pv_df = result.get("pv")
    if isinstance(pv_df, pd.DataFrame) and not pv_df.empty:
        bad = pv_df.columns[pv_df.isna().all()].tolist()
        tc.record("pv_no_all_nan",  not bad,  f"All-NaN cols: {bad}")
        tc.record("pv_no_negative", (pv_df >= 0).all().all(),
                  "Negative PV values found")
        if check_pv_night and isinstance(times, pd.DatetimeIndex) \
                and len(times) > 0:
            night = (times.hour >= 22) | (times.hour <= 4)
            tc.record(
                "pv_zero_at_night",
                (pv_df.loc[night] < 0.001).all().all(),
                "Non-zero PV found at night hours",
            )

    # Wind checks
    wind_df = result.get("wind")
    if isinstance(wind_df, pd.DataFrame) and not wind_df.empty:
        bad = wind_df.columns[wind_df.isna().all()].tolist()
        tc.record("wind_no_all_nan",   not bad, f"All-NaN cols: {bad}")
        tc.record("wind_no_negative",  (wind_df >= 0).all().all(),
                  "Negative wind values found")
        tc.record("wind_max_plausible", wind_df.max().max() < 1000,
                  f"Max wind {wind_df.max().max():.1f} MW exceeds 1000 MW")
